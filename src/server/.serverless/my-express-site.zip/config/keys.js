module.exports = {
    mongoURI: 'mongodb+srv://wstumbo:ADFAAZID11jimmy@cluster0-ohlo4.mongodb.net/personalsite?retryWrites=true',
    secretOrKey: 'secret'
  };
  